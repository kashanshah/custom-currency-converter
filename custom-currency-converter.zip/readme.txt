=== Custom Currency Converter ===
Author: kashanshah
Tags: currency converter, cryptocurrency, wordpress
Requires at least: 5.1
Tested up to: 5.7.1
Requires PHP: 7.0
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Custom WordPress Currency Converter

== Description ==
This plugin provides a widget for Currency Converter, where you can manage currency rates through the admin panel. ou may also add custom currencies, cryptocurrencies, gift cards and all type of currency conversions.

== Installation ==
1. Upload \"custom-currency-connverter.zip\" to the \"/wp-content/plugins/\" directory.
2. Activate the plugin through the \"Plugins\" menu in WordPress.